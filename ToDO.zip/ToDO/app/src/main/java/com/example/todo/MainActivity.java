package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private Button Login;
    private  int count=5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name = (EditText)findViewById(R.id.editTextTextPersonName);
        Password = (EditText)findViewById(R.id.editTextTextPersonName);
        Login = (Button)findViewById(R.id.button);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(Name.getText().toString(),Password.getText().toString());
            }
        });
    }

    private void validate(String UserName,String UserPassword){
        if((UserName.equals("Hemanth")) && (UserPassword.equals("Hemanth"))){
            Intent intent = new Intent(MainActivity.this,SecondActivity.class);
            startActivity(intent);
        }
        else{
                count--;
            Toast.makeText(getApplicationContext(),"Incorrect login details."+count+" Attempts remaining",Toast.LENGTH_LONG);
                if(count==0){
                    Login.setEnabled(false);
                }
        }
    }

}